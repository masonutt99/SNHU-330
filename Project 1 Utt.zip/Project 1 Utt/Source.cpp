///////////////////////////////////////////////////////////////////////////////
// source.cpp
// ========
// drawing a complex cylinder using (glDrawElements)
// dependency: freeglut/glut
//
//  AUTHOR: Mason Utt
// 
// Base code: Song Ho Ahn (song.ahn@gmail.com)
// Modified for CS330 December 4 2022
///////////////////////////////////////////////////////////////////////////////


#include"Libs.h"


// GLUT CALLBACK functions
void displayCB();
void reshapeCB(int w, int h);
void timerCB(int millisec);
void keyboardCB(unsigned char key, int x, int y);
void mouseCB(int button, int stat, int x, int y);
void ProcessMouseScroll(int x, int y);
void mouseMotionCB(int x, int y);

void initGL();
int  initGLUT(int argc, char** argv);
bool initSharedMem();
void clearSharedMem();
void initLights();
void setCamera(float posX, float posY, float posZ, float targetX, float targetY, float targetZ);
void toOrtho();
void toPerspective();
GLuint loadTexture(const char* fileName, bool wrap = true);


// constants
const int   SCREEN_WIDTH = 1500;
const int   SCREEN_HEIGHT = 500;
const float CAMERA_DISTANCE = 10.0f;



// global variables
void* font = GLUT_BITMAP_8_BY_13;
int screenWidth;
int screenHeight;
bool mouseLeftDown;
bool mouseRightDown;
bool mouseMiddleDown;
float mouseX, mouseY;
float cameraAngleX;
float cameraAngleY;
float cameraAngleZ;
float cameraDistance;
int drawMode;
GLuint brick;
GLuint desk;
GLuint green;
GLuint pencilTip;
GLuint pencilWood;
GLuint red;
GLuint steel;
GLuint glass;
GLuint ball;
int imageWidth;
int imageHeight;

bool orth;


float Speed = 2.5f;



// cylinder: min sectors = 3, min stacks = 1
Cylinder cylinder1(.250f, .250f, 2.0f, 36, 8);      // baseRadius, topRadius, height, sectors, stacks
Cylinder cylinder2(1.0f, 1.0f, 3.0f, 36, 8);        // baseRadius, topRadius, height, sectors, stacks
Cylinder cylinder3(.250f, .0f, .50f, 36, 8);

Cylinder pole(.2f, .2f, 5.0f, 12, 8);
Cylinder goal(.5f, .5f, 1.0f, 12, 8);
Cylinder triangle(4.25f, 0.0f, 3.0f, 4, 8);
Sphere sphere1(1.0f, 18, 18);                       // radius, sectors, stacks, smooth(default)

///////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv)
{
    // init global vars
    initSharedMem();

    // init GLUT and GL
    initGLUT(argc, argv);
    initGL();


    // load BMP image
    brick = loadTexture("brick.bmp", true);
    desk = loadTexture("desk.bmp", true);
    green = loadTexture("green.bmp", true);
    pencilTip = loadTexture("pencilTip.bmp", true);
    pencilWood = loadTexture("pencilWood.bmp", true);
    red = loadTexture("red.bmp", true);
    steel = loadTexture("steel.bmp", true);
    glass = loadTexture("glass.bmp", true);
    ball = loadTexture("ball.bmp", true);
    // the last GLUT call (LOOP)
    // window will be shown and display callback is triggered by events
    // NOTE: this call never return main().
    glutMainLoop(); /* Start GLUT event-processing loop */

    return 0;
}



///////////////////////////////////////////////////////////////////////////////
// initialize GLUT for windowing
///////////////////////////////////////////////////////////////////////////////
int initGLUT(int argc, char** argv)
{
    // GLUT stuff for windowing
    // initialization openGL window.
    // it is called before any other GLUT routine
    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL);   // display mode

    glutInitWindowSize(screenWidth, screenHeight);  // window size

    glutInitWindowPosition(100, 100);               // window location

    // finally, create a window with openGL context
    // Window will not displayed until glutMainLoop() is called
    // it returns a unique ID
    int handle = glutCreateWindow(argv[0]);     // param is the title of window

    // register GLUT callback functions
    glutDisplayFunc(displayCB);
    glutTimerFunc(33, timerCB, 33);             // redraw only every given millisec
    glutReshapeFunc(reshapeCB);
    glutKeyboardFunc(keyboardCB);
    glutMouseFunc(mouseCB);
    glutMotionFunc(ProcessMouseScroll);
    glutMotionFunc(mouseMotionCB);

    return handle;
}



///////////////////////////////////////////////////////////////////////////////
// initialize OpenGL
// disable unused features
///////////////////////////////////////////////////////////////////////////////
void initGL()
{
    glShadeModel(GL_SMOOTH);                    // shading mathod: GL_SMOOTH or GL_FLAT
    glPixelStorei(GL_UNPACK_ALIGNMENT, 4);      // 4-byte pixel alignment

    // enable /disable features
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
    //glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_CULL_FACE);

    // track material ambient and diffuse from surface color, call it before glEnable(GL_COLOR_MATERIAL)
   //glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
   //glEnable(GL_COLOR_MATERIAL);

    glClearColor(0, 0, 0, 0);                   // background color
    glClearStencil(0);                          // clear stencil buffer
    glClearDepth(1.0f);                         // 0 is near, 1 is far
    glDepthFunc(GL_LEQUAL);

    initLights();
}



///////////////////////////////////////////////////////////////////////////////
// initialize global variables
///////////////////////////////////////////////////////////////////////////////
bool initSharedMem()
{
    screenWidth = SCREEN_WIDTH;
    screenHeight = SCREEN_HEIGHT;

    mouseLeftDown = mouseRightDown = mouseMiddleDown = false;
    mouseX = mouseY = 0;

    cameraAngleX = cameraAngleY = cameraAngleZ = 0.0f;
    cameraDistance = CAMERA_DISTANCE;

    drawMode = 0; // 0:fill, 1: wireframe, 2:points

    return true;
}



///////////////////////////////////////////////////////////////////////////////
// clean up global vars
///////////////////////////////////////////////////////////////////////////////
void clearSharedMem()
{
}



///////////////////////////////////////////////////////////////////////////////
// initialize lights
///////////////////////////////////////////////////////////////////////////////
void initLights()
{
    //// set up light colors (ambient, diffuse, specular)
    GLfloat lightKa[] = { 01.0f, 01.0f, 01.0f, .80f };  // ambient light
    GLfloat lightKd[] = { 1.0f, 1.0f, 1.0f, .80f };  // diffuse light
    GLfloat lightKs[] = { 1, 1, 1, 1 };           // specular light
    glLightfv(GL_LIGHT0, GL_AMBIENT, lightKa);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightKd);
    glLightfv(GL_LIGHT0, GL_SPECULAR, lightKs);

    // position the light
    float lightPos[4] = { 0.50f, 5.0f, 05.0f, 0.0f }; // directional light
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
    glEnable(GL_LIGHT0);                        // MUST enable each light source after configuration

    // set up light colors (ambient, diffuse, specular)
    GLfloat lightKa2[] = { 01.0f, 0.250f, 0.250f, .750f };  // ambient light
    GLfloat lightKd2[] = { 01.0f, 0.250f, 0.250f, .750f };  // diffuse light
    GLfloat lightKs2[] = { 1.0f, 1.0f, 1.0f, .9f };           // specular light
    glLightfv(GL_LIGHT1, GL_AMBIENT, lightKa2);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, lightKd2);
    glLightfv(GL_LIGHT1, GL_SPECULAR, lightKs2);

    // position the light
    float lightPos2[4] = { 05.0f, 06.50f, 0.0f, 00.0f }; // directional light
    glLightfv(GL_LIGHT1, GL_POSITION, lightPos2);
    glEnable(GL_LIGHT1);                        // MUST enable each light source after configuration

}



///////////////////////////////////////////////////////////////////////////////
// set camera position and lookat direction
///////////////////////////////////////////////////////////////////////////////
void setCamera(float posX, float posY, float posZ, float targetX, float targetY, float targetZ)
{
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(posX, posY, posZ, targetX, targetY, targetZ, 0, 1, 0); // eye(x,y,z), focal(x,y,z), up(x,y,z)
}

///////////////////////////////////////////////////////////////////////////////
// load raw image as a texture
///////////////////////////////////////////////////////////////////////////////
GLuint loadTexture(const char* fileName, bool wrap)
{
    Image::Bmp bmp;
    if (!bmp.read(fileName))
        return 0;     // exit if failed load image

    // get bmp info
    int width = bmp.getWidth();
    int height = bmp.getHeight();
    const unsigned char* data = bmp.getDataRGB();
    GLenum type = GL_UNSIGNED_BYTE;    // only allow BMP with 8-bit per channel

    // We assume the image is 8-bit, 24-bit or 32-bit BMP
    GLenum format;
    int bpp = bmp.getBitCount();
    if (bpp == 8)
        format = GL_LUMINANCE;
    else if (bpp == 24)
        format = GL_RGB;
    else if (bpp == 32)
        format = GL_RGBA;
    else
        return 0;               // NOT supported, exit

    // gen texture ID
    GLuint texture;
    glGenTextures(1, &texture);

    // set active texture and configure it
    glBindTexture(GL_TEXTURE_2D, texture);

    // select modulate to mix texture with color for shading
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    //glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);

    // if wrap is true, the texture wraps over at the edges (repeat)
    //       ... false, the texture ends at the edges (clamp)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrap ? GL_REPEAT : GL_CLAMP);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrap ? GL_REPEAT : GL_CLAMP);
    //glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    //glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    // copy texture data
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
    //glGenerateMipmap(GL_TEXTURE_2D);

    // build our texture mipmaps
    switch (bpp)
    {
    case 8:
        gluBuild2DMipmaps(GL_TEXTURE_2D, 1, width, height, GL_LUMINANCE, GL_UNSIGNED_BYTE, data);
        break;
    case 24:
        gluBuild2DMipmaps(GL_TEXTURE_2D, 3, width, height, GL_RGB, GL_UNSIGNED_BYTE, data);
        break;
    case 32:
        gluBuild2DMipmaps(GL_TEXTURE_2D, 4, width, height, GL_RGBA, GL_UNSIGNED_BYTE, data);
        break;
    }

    return texture;
}

///////////////////////////////////////////////////////////////////////////////
// set projection matrix as orthogonal
///////////////////////////////////////////////////////////////////////////////
void toOrtho()
{
    // set viewport to be the entire window
    glViewport(0, 0, (GLsizei)screenWidth, (GLsizei)screenHeight);

    // set orthographic viewing frustum
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0f, screenWidth, screenHeight, 0.0f, 0.0f, 1.0f);

    // switch to modelview matrix in order to set scene
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}



///////////////////////////////////////////////////////////////////////////////
// set the projection matrix as perspective
///////////////////////////////////////////////////////////////////////////////
void toPerspective()
{
    // set viewport to be the entire window
    glViewport(0, 0, (GLsizei)screenWidth, (GLsizei)screenHeight);

    // set perspective viewing frustum
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f, (float)(screenWidth) / screenHeight, 1.0f, 1000.0f); // FOV, AspectRatio, NearClip, FarClip

    // switch to modelview matrix in order to set scene
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}


//draws the plane
void draw1()
{
    glPushMatrix();

    glBegin(GL_QUADS);
    // face v0-v1-v2-v3
    glNormal3f(0, 0, 1);
    glColor3f(1, 1, 1);
    glVertex3f(15, -1.5, 15);
    glColor3f(1, 1, 0);
    glVertex3f(-15, -1.5, 15);
    glColor3f(1, 0, 0);
    glVertex3f(-15, -1.5, 15);
    glColor3f(1, 0, 1);
    glVertex3f(15, -1.5, 15);

    // face v0-v3-v4-v6
    glNormal3f(1, 0, 0);
    glColor3f(1, 1, 1);
    glVertex3f(15, -1.5, 15);
    glColor3f(1, 0, 1);
    glVertex3f(15, -1.5, 15);
    glColor3f(0, 0, 1);
    glVertex3f(15, -1.5, -15);
    glColor3f(0, 1, 1);
    glVertex3f(15, -1.5, -15);

    // face v0-v5-v6-v1
    glNormal3f(0, 1, 0);
    glColor3f(1, 1, 1);
    glVertex3f(15, -1.5, 15);
    glColor3f(0, 1, 1);
    glVertex3f(15, -1.5, -15);
    glColor3f(0, 1, 0);
    glVertex3f(-15, -1.5, -15);
    glColor3f(1, 1, 0);
    glVertex3f(-15, -1.5, 15);

    // face  v1-v6-v7-v2
    glNormal3f(-1, 0, 0);
    glColor3f(1, 1, 0);
    glVertex3f(-15, -1.5, 15);
    glColor3f(0, 1, 0);
    glVertex3f(-15, -1.5, -15);
    glColor3f(0, 0, 0);
    glVertex3f(-15, -1.5, -15);
    glColor3f(1, 0, 0);
    glVertex3f(-15, -1.5, 15);

    // face v7-v4-v3-v2
    glNormal3f(0, -1, 0);
    glColor3f(0, 0, 0);
    glVertex3f(-15, -1.5, -15);
    glColor3f(0, 0, 1);
    glVertex3f(15, -1.5, -15);
    glColor3f(1, 0, 1);
    glVertex3f(15, -1.5, 15);
    glColor3f(1, 0, 0);
    glVertex3f(-15, -1.5, 15);

    // face v4-v7-v6-v5
    glNormal3f(0, 0, -1);
    glColor3f(0, 0, 1);
    glVertex3f(15, -1.5, -15);
    glColor3f(0, 0, 0);
    glVertex3f(-15, -1.5, -15);
    glColor3f(0, 1, 0);
    glVertex3f(-15, -1.5, -15);
    glColor3f(0, 1, 1);
    glVertex3f(15, -1.5, -15);
    glEnd();

    glPopMatrix();
}


//draws box
void draw2(float size, float height)
{
    glPushMatrix();

    glBegin(GL_QUADS);

    //top
    
    glNormal3f(0.0f, 1.0f, 0.0f);

    glVertex3f(-size, height, size);
    glVertex3f(size, height, size);
    glVertex3f(size, height, -size);
    glVertex3f(-size, height, -size);

    // front
    
    glNormal3f(0.0f, 0.0f, 1.0f);

    glVertex3f(size, -height, size);
    glVertex3f(size, height, size);
    glVertex3f(-size, height, size);
    glVertex3f(-size, -height, size);

    // right
    
    glNormal3f(1.0f, 0.0f, 0.0f);

    glVertex3f(size, height, -size);
    glVertex3f(size, height, size);
    glVertex3f(size, -height, size);
    glVertex3f(size, -height, -size);

    // left
    
    glNormal3f(-1.0f, 0.0f, 0.0f);

    glVertex3f(-size, -height, size);
    glVertex3f(-size, height, size);
    glVertex3f(-size, height, -size);
    glVertex3f(-size, -height, -size);

    // bottom
    
    glNormal3f(0.0f, -1.0f, 0.0f);

    glVertex3f(size, -height, size);
    glVertex3f(-size, -height, size);
    glVertex3f(-size, -height, -size);
    glVertex3f(size, -height, -size);

    // back
    
    glNormal3f(0.0f, 0.0f, -1.0f);

    glVertex3f(size, height, -size);
    glVertex3f(size, -height, -size);
    glVertex3f(-size, -height, -size);
    glVertex3f(-size, height, -size);


    glEnd();

    glPopMatrix();
}


//=============================================================================
// CALLBACKS
//=============================================================================

void displayCB()
{
    // clear buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

    // save the initial ModelView matrix before modifying ModelView matrix
    glPushMatrix();

    // tramsform camera
    glTranslatef(0, 0, -cameraDistance);
    glRotatef(cameraAngleX, 1, 0, 0);   // pitch
    glRotatef(cameraAngleY, 0, 1, 0);   // heading
    glRotatef(cameraAngleZ, 0, 0, 1);   // heading

    //draw the plane
    glBindTexture(GL_TEXTURE_2D, desk);
    draw1();

    // set material
    float ambient[] = { 0.5f, 0.5f, 0.5f, 1 };
    float diffuse[] = { 0.8f, 0.8f, 0.8f, 1 };
    float specular[] = { 1.0f, 1.0f, 1.0f, 1 };

    float shininess = 128;
    glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
    glMaterialf(GL_FRONT, GL_SHININESS, shininess);

    // draw middle cylinder or pencil
    glPushMatrix();
    glTranslatef(-5.0f, 1.50f, 05.0f);
    glRotatef(-90, 1, 0, 0);
    glBindTexture(GL_TEXTURE_2D, pencilWood);
    cylinder1.draw();
    glPopMatrix();

    // draw bottom cylinder or pencil holder
    glPushMatrix();
    glTranslatef(-5.0f, 0.0f, 05.0f);
    glRotatef(-90, 1, 0, 0);
    glBindTexture(GL_TEXTURE_2D, green);
    cylinder2.draw();
    glPopMatrix();

    // draw top of pencil a cone
    glPushMatrix();
    glTranslatef(-5.0f, 2.75f, 05.0f);
    glRotatef(-90, 1, 0, 0);
    glBindTexture(GL_TEXTURE_2D, pencilTip);
    cylinder3.draw();
    glPopMatrix();


    
    glTranslatef(05.0f, 2.0f, 0.0f);
    glBindTexture(GL_TEXTURE_2D, red);
    draw2(3.0f, .5f);

    glTranslatef(0.0f, -2.0f, 0.0f);
    glBindTexture(GL_TEXTURE_2D, green);
    draw2(3.0f, 1.5f);

    glPushMatrix();
    glTranslatef(0.0f, 04.0f, 0.0f);
    glRotatef(-90, 1, 0, 0);
    glRotatef(45, 0, 0, 01);
    glBindTexture(GL_TEXTURE_2D, green);
    triangle.draw();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(05.0f, -0.50f, 05.0f);
    glRotatef(-90, 1, 0, 0);
    glBindTexture(GL_TEXTURE_2D, ball);
    sphere1.draw();
    glPopMatrix();

    glTranslatef(0.0f, -0.50f, 03.0f);
    glBindTexture(GL_TEXTURE_2D, red);
    glRotatef(-90, 1, 0, 0);
    draw2(1.0f, .25f);


    glPushMatrix();
    glTranslatef(-5.0f, -5.0f, 01.50f);
    glBindTexture(GL_TEXTURE_2D, steel);
    pole.draw();
    glPopMatrix();

    glTranslatef(-5.0f, -5.0f, 05.0f);
    glBindTexture(GL_TEXTURE_2D, glass);
    draw2(1.50f, .25f);


    glPushMatrix();
    glTranslatef(.0f, -.750f, -0.50f);
    glBindTexture(GL_TEXTURE_2D, green);
    goal.draw();
    glPopMatrix();

    glPopMatrix();
    glutSwapBuffers();


}


void reshapeCB(int w, int h)
{
    screenWidth = w;
    screenHeight = h;
    toPerspective();
    //toOrtho();
    std::cout << "window resized: " << w << " x " << h << std::endl;
}


void timerCB(int millisec)
{
    glutTimerFunc(millisec, timerCB, millisec);
    glutPostRedisplay();
}


void keyboardCB(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 27: // ESCAPE
        clearSharedMem();
        exit(0);
        break;

    case 'd': // move the camera to the right
    case 'D':
        cameraAngleY -= 1 * Speed;
        break;
    case 'a': // move the camera to the left
    case 'A':
        cameraAngleY += 1 * Speed;
        break;

    case 'w': // move the camera forward
    case 'W':
        cameraDistance -= 1 * Speed;
        break;

    case 's': // move the camera backward
    case 'S':
        cameraDistance += 1 * Speed;
        break;

    case 'q': // move the camera up
    case 'Q':
        cameraAngleX += 1 * Speed;
        break;

    case 'e': // move the camera down
    case 'E':
        cameraAngleX -= 1 * Speed;
        break;
    case 'p':
    case 'P':
        if (orth) {
            toPerspective();
            orth = false;
        }
        else {
            toOrtho();
            orth = true;
        }
        break;
    //case ' ':
    //{
    //    int count = cylinder1.getSectorCount();
    //    if (count < 36)
    //        count += 4;
    //    else
    //        count = 4;
    //    cylinder1.setSectorCount(count);
    //    cylinder2.setSectorCount(count);
    //    cylinder3.setSectorCount(count);
    //    cylinder1.setStackCount(count / 4);
    //    cylinder2.setStackCount(count / 4);
    //    cylinder3.setStackCount(count / 4);
    //    break;
    //}

    default:
        ;
    }
}


void mouseCB(int button, int state, int x, int y)
{
    mouseX = x;
    mouseY = y;

    if (button == GLUT_LEFT_BUTTON)
    {
        if (state == GLUT_DOWN)
        {
            mouseLeftDown = true;
        }
        else if (state == GLUT_UP)
            mouseLeftDown = false;
    }

    else if (button == GLUT_RIGHT_BUTTON)
    {
        if (state == GLUT_DOWN)
        {
            mouseRightDown = true;
        }
        else if (state == GLUT_UP)
            mouseRightDown = false;
    }

    else if (button == GLUT_MIDDLE_BUTTON)
    {
        if (state == GLUT_DOWN)
        {
            mouseMiddleDown = true;
        }
        else if (state == GLUT_UP)
            mouseMiddleDown = false;
    }
}



void ProcessMouseScroll(int x, int y)
{
    if (mouseMiddleDown) {
        Speed += (x - mouseX) * Speed;        //mouse scroll affects the speed of movement
        if (Speed < 1.0f)
            Speed = 1.0f;
        if (Speed > 50.0f)
            Speed = 50.0f;
        mouseX = x;
    }
}

void mouseMotionCB(int x, int y)
{
    if (mouseLeftDown)
    {
        cameraAngleY += (x - mouseX) * Speed;
        cameraAngleX += (y - mouseY) * Speed;
        mouseX = x;
        mouseY = y;
    }
    if (mouseRightDown)
    {
        cameraDistance -= (y - mouseY) * 0.2f * Speed;
        mouseY = y;
    }
}